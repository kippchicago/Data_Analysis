library(testthat)

suppressPackageStartupMessages(test_check("TestS4"))
