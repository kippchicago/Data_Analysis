#' tidyjson.
#'
#' @name tidyjson
#' @docType package
#' @import assertthat
#' @import jsonlite
#' @import dplyr
NULL
