/* Dmitriy Selivanov (2014) https://github.com/dselivanov */
#include <Rinternals.h>
int* _IS_NA(SEXP x);
