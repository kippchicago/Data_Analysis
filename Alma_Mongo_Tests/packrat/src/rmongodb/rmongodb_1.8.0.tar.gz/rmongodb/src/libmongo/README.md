MongoDB C Driver
================================

Version: 0.7.1

URL: https://github.com/mongodb/mongo-c-driver

Description: Libmongoc is a client library written in C for MongoDB.