#' cellranger
#'
#' Helper functions to work with spreadsheets and the "A1:D10" style of cell
#' range specification.
#'
#' @name cellranger
#' @docType package
NULL
