Takes an enormous screenshot and makes it look decent embedded in the vignette:

```
convert gs-test-formula-formatting-screenshot.png -resize 675x675  gs-test-formula-formatting-screenshot-smaller.png
```
