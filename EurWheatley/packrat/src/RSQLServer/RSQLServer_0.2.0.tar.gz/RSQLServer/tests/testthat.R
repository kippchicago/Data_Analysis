library(testthat)
library(RSQLServer)

test_check("RSQLServer")
