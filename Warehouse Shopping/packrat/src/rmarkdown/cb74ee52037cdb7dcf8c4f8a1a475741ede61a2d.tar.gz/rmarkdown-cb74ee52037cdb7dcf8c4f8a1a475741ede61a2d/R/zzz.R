.onLoad <- function(lib, pkg) {
  .render_context <<- new_stack()
}
